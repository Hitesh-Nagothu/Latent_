from langdetect import detect
from langdetect import DetectorFactory
from googletrans import Translator, constants
from pprint import pprint
import urllib.request
import http.client
import json
import pandas as pd
import sys
"""
This file is used to translate the query the user entered 
on the website into a url that is passed to Solr.
"""
#---------------------------------------------------------
# The   translate_query   function takes a query and
# translates it into the four following languages: en, hi,
# it, and pt. Returns list with translated query words.
#
# THIS FUNCTION IS NOT WORKING. There is something wrong
# with the imported class googletrans. I left it in here
# in case someone else can get it to work. An explanation
# of what is happening is in the googletrans\gtoken.py file.
#---------------------------------------------------------
"""
def translate_query(query):
    # Will store translated query
    translated_query = []
    
    # init the Google API translator
    translator = Translator()
    
    # Translate query into en, hi, it, and pt and store in translated_query
    translation = translator.translate(str(query), dest='en', src=str(detect(query)))
    translated_query.append(translation)
    translation = translator.translate(str(query), dest='hi', src=str(detect(query)))
    translated_query.append(translation)
    translation = translator.translate(str(query), dest='it', src=str(detect(query)))
    translated_query.append(translation)
    translation = translator.translate(str(query), dest='pt', src=str(detect(query)))
    translated_query.append(translation)
    
    return translated_query
    
"""
#---------------------------------------------------------
# The   solr_url()   function takes a str as an argument
# and creates a url that will be passed to Solr. Returns 
# the created url.
#---------------------------------------------------------
def solr_url(query):
    # Solr url, subject to change based off starting/stopping ec2 instance!
    solr_url = 'http://54.86.70.216:8983/solr/IR2020/'
    # Punctutaion to use in solr_url
    comma = '%2C%20'
    # Use list to search for query in all languages
    langs = ['text_en', 'full_text_en', 'text_hi', 'full_text_hi', 'text_it', 'full_text_it']
    
    # Search all tweets if no query entered; else, search Solr with user query
    if not query:
        solr_url_with_query = solr_url + 'select?fl=created_at%2C%20poi_name%2C%20id%2C%20country%2C%20tweet_text%2C%20full_text_en%2C%20tweet_lang%2C%20hashtags%2C%20mentions%2C%20tweet_urls%2C%20tweet_emoticons%2C%20tweet_date%2C%20retweet_count&q=*%3A*&rows=300&wt=json'
    else:
        # Strip query of [''] format
        query = str(query).strip("['']")
        
        # Replace spaces with Solr space code
        query = query.replace(' ', '%20')

        # This is not working! It is dependent
        # on the translate_query() function working.
        """
        # Translations of query will be stored here
        translated_query = []
        # Translate query into en, hi, it, and pt and store in translated_query list
        translated_query = translate_query(query)
        """

        # Create Solr url to search query in all language fields where query is NOT translated.
        solr_url_with_query = solr_url + 'select?fl=created_at%2C%20poi_name%2C%20id%2C%20country%2C%20tweet_text%2C%20full_text_en%2C%20tweet_lang%2C%20hashtags%2C%20mentions%2C%20tweet_urls%2C%20tweet_emoticons%2C%20tweet_date%2C%20retweet_count' + '&q=' + '(' + langs[0] + '%3A%20' + '(' + str(query) + ')' + ')' + '%20OR%20' + '(' + langs[2] + '%3A%20' + '(' + str(query) + ')' + ')' + '%20OR%20' + '(' + langs[4] + '%3A%20' + '(' + str(query) + ')' + ')' + '&rows=300&wt=json'

    return solr_url_with_query

#---------------------------------------------------------
# The   refine_by_solr_query()   function takes the refine 
# by menu fields and tweet results. Searches through and
# saves tweets that meet refine by specifications. Returns
# refined tweets list.
#---------------------------------------------------------
def refine_by_solr_query(lang, date, POI, country, hashtags, tweets):
    # List where refined tweet results will be stored
    refined_tweets = []
    
    # Loop through tweets and check if they meet refine by criteria
    for x in tweets:
        if (x['tweet_lang'] == lang or x['tweet_lang'] == 'All') and (x['created_at'] == date or x['created_at'] == 'All') and (x['poi_name'] == POI or x['poi_name'] == 'All') and (x['country'] == country or x['country'] == 'All') and (x['hashtags'] == hashtags or x['hashtags'] == 'All'):
            refined_tweets.append(x)
        else:
            continue
    # Return refined tweet results
    return refined_tweets
    
#---------------------------------------------------------
# The   search_solr()   function takes a url as an
# argument and passes it to Solr. Returns None.
#---------------------------------------------------------
def search_solr(url):
    # Results will be stored in this file in json format
    filename = 'query_results.json'
    # Open file
    outf = open(filename, 'w', encoding='utf-8')
    
    # Execute url and dump into file
    data = urllib.request.urlopen(url)
    
    # Load tweets into variable
    docs = json.load(data)['response']['docs']
    
    return docs

#---------------------------------------------------------
# The   print_formatted_tweets()   function takes the json
# file where the tweets are stored and prints to pandas
# dataframe. Return the dataframe.
#---------------------------------------------------------     
def print_formatted_tweets(tweets):
    # Specific tweet fields will be saved in this list for future dataframe
    tweets_list = []
    
    # Loop through each tweet and append specific info to temp list
    for tweet in tweets:
          info=[]
          id=tweet['id']
          created_at=tweet['created_at']
          raw_text=tweet['full_text_en']
          retweet_count=tweet['retweet_count']

          info.append([id,created_at,raw_text, retweet_count])

          tweets_list.append(info[0])

    tweets_df = pd.DataFrame(data=tweets_list,columns=['tweet_id', 'created_at', 'tweet_text', 'rt'])
    pd.set_option('display.max_rows', None)
    pd.set_option('display.max_columns', None)
    pd.set_option('display.width', None)
    pd.set_option('display.max_colwidth', None)

    return tweets_df
    
#---------------------------------------------------------
# The   main()   function takes the query entered on
# website and calls neccesary functions to return search
# results from Solr.
#---------------------------------------------------------    
def main(query):
    # Create Solr url to search Solr with entered query. Store in variable.
    url = solr_url(query)
    # Search Solr and print results to file in json format
    results = search_solr(url)
    # Format tweets into pandas dataframe to print on website
    tweets_df = print_formatted_tweets(results)
    
    return tweets_df